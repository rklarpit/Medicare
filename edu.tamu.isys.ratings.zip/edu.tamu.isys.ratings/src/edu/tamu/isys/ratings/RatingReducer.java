package edu.tamu.isys.ratings;
import java.io.IOException;
import java.lang.String;
import java.util.ArrayList;

//import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
public class RatingReducer extends
Reducer<Text, Text, Text, Text>{
	private String MovieString="";
	private String MovieName = "";
	private String RatingValue = "";
	private String CheckName ="";
     int sum =0;
    String TopMovie = "";
    double AvgRating =0.0;
     int count = 0;
     double TopRating =0.0;
	public void reduce(Text key, Iterable<Text> values,
			Context context) throws IOException, InterruptedException {
		
		ArrayList<String> mov = new ArrayList<String>();  
		int movlen =0;
		for (Text value : values) {
			MovieString=   value.toString();
			System.out.println(MovieString);
			mov.add(MovieString);
			/*System.out.println("Movie String is" + MovieString);
			String[] Parts = MovieString.split("<<>>");
			this.MovieName = Parts[0].trim();
			count ++;
			System.out.println("Counting for" + MovieName + " and my value is" + count);
			if (MovieName != CheckName){
				
				AvgRating = sum/count;
				if (AvgRating > TopRating){
					TopRating =AvgRating;
				    TopMovie = CheckName; 
				    System.out.println("Now TopMovie is " + TopMovie + " and TopRating is" + TopRating);
				}
				CheckName = MovieName;
				sum =0;	
				AvgRating =0 ;
				count =0;
				 System.out.println("Now CheckName is " +  CheckName);
			}
			this.RatingValue = Parts[1].trim();
			sum += Integer.parseInt(RatingValue);
			System.out.println(RatingValue+" "+sum);
			}
		Text TopValue = new Text (TopMovie + String.valueOf(TopRating));
		context.write(key,TopValue);*/
			
		
}
	movlen = mov.size();
	String temp ="";
	 for (int x=0; x<movlen; x++) // bubble sort outer loop
     {
         for (int i=0; i < movlen-x-1; i++) {
             if (mov.get(i).compareTo(mov.get(i+1)) > 0)
             {
                 temp = mov.get(i);
                 mov.set(i,mov.get(i+1) );
                 mov.set(i+1, temp);
             }
         }
     }
	 for (int x=0; x<movlen; x++)
	 {
		 System.out.println("for Genre " + key + " movie details " + mov.get(x));
	 }
	 for (int x=0; x<movlen; x++)
	 {
		 String[] Parts = mov.get(x).split("<<>>");
			this.MovieName = Parts[0].trim();
			
			System.out.println("Counting for" + MovieName);
			if (MovieName.compareTo(CheckName) != 0){
				if (count !=0){
				    System.out.println("Sum for Outgoing Movie " + CheckName +" is " + sum);
					AvgRating = sum/count;
					System.out.println("Average for Outgoing Movie " + CheckName +" is " + AvgRating);
				
				if (AvgRating > TopRating){
					TopRating = AvgRating;
				    TopMovie = CheckName; 
				}
				    System.out.println("Now TopMovie is " + TopMovie + " and TopRating is" + TopRating);
				    sum =0;	
					AvgRating =0 ;
					count =0;
				}
				}
				CheckName = MovieName;
				
				 System.out.println("Now CheckName is " +  CheckName);
			
			count ++;
			this.RatingValue = Parts[1].trim();
			sum += Integer.parseInt(RatingValue);
			
			System.out.println("SumRatingValue " + sum + "and count is " + count );
			}
		Text TopValue = new Text (TopMovie + String.valueOf(TopRating));
		context.write(key,TopValue);
	 System.out.println("TopMovie is" + TopMovie + " and its rating is" + TopRating  );
	 
	 //Text S = new Text(mov.get(2));
	 //context.write(key,S);
}
	 
	
}