package edu.tamu.isys.ratings;

import java.io.IOException;

//import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class RatingMapper extends
Mapper<LongWritable, Text, Text, Text>{
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String MovieData = value.toString();
		RatingAnalyzer MovieEntry = new RatingAnalyzer(MovieData);
         String mapperKey = new String();
         int len = MovieEntry.getLength();
         String ratingValue = "";
         ratingValue = MovieEntry.getRating();
         System.out.println("My Rating is" + ratingValue);
         String movieValue = "";
         movieValue = MovieEntry.getMovie() + "<<>>" + ratingValue;
         Text mValue = new Text(movieValue);
         System.out.println("I am under mvalue");
         for(int i=0;i < len; i++){
         mapperKey = MovieEntry.getGenre2(i);
         Text mKey = new Text(mapperKey);
         System.out.println("I am "+MovieEntry.getGenre2(i) + "for Movie and Rating " + movieValue);
         System.out.println("mkey is" + mKey + " mValue is " + mValue);
         context.write(mKey,mValue);
         
         }
}
}
